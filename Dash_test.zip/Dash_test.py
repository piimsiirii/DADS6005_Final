import dash
import dash_html_components as html
import dash_core_components as dcc
import requests
import datetime
from dash.dependencies import Input, Output
import json

# Currency Exchange
url_currency = "https://fixer-fixer-currency-v1.p.rapidapi.com/latest"

querystring = {"base":"USD","symbols":"THB"}

headers_currency = {
	"X-RapidAPI-Key": "c7ef6b2039msh7ffcf6a6246db85p143fcfjsn6cb6b71a6935",
	"X-RapidAPI-Host": "fixer-fixer-currency-v1.p.rapidapi.com"
}


figure1 = dict(
    data=[{'x': [], 'y': []}], 
    layout=dict(
        xaxis=dict(range=[]), 
        yaxis=dict(range=[])
        )
    )
	
# Gold Price
url_gold = "https://gold-price1.p.rapidapi.com/get_price/USD"

headers_gold = {
	"X-RapidAPI-Key": "06afad3678msh99f0226a1f42a61p19ff6cjsn0a32a10590b3",
	"X-RapidAPI-Host": "gold-price1.p.rapidapi.com"
}

figure2 = dict(
    data=[{'x': [], 'y': []}], 
    layout=dict(
        xaxis=dict(range=[]), 
        yaxis=dict(range=[])
        )
    )
	

app = dash.Dash(__name__, update_title=None)

app.layout = html.Div(
        [   
            html.H1(children='Exchange rate from THB to 1 USD', style = {'color': '#000000', 'backgroundColor': "#E2B741"}),
            dcc.Graph(id='graph', figure=figure1), 
            dcc.Interval(id="interval",interval= 60*1000),
            html.H1(children='Gold price(USD)', style = {'color': '#000000', 'backgroundColor': "#E2B741"}),
            dcc.Graph(id='graph2', figure=figure2), 
            dcc.Interval(id="interval2",interval= 60*1000)
        ]
    )
    
@app.callback(
    Output('graph', 'extendData'), 
    [Input('interval', 'n_intervals')])
    
def update_data(n_intervals):

    print("interval ",n_intervals)

    data_currency = requests.request("GET", url_currency, headers=headers_currency, params=querystring)
    data_currency = data_currency.text
    data_currency = json.loads(data_currency)
    print(data_currency)
    
    myDate = data_currency['date']
    base_currency = data_currency['base']
    rate_currency = float(data_currency['rates']['THB'])
    timeStamp = data_currency['timestamp']
    my_datetime = datetime.datetime.fromtimestamp(timeStamp)   

    return dict(x=[[my_datetime]], y=[[rate_currency]])
    
@app.callback(
    Output('graph2', 'extendData'), 
    [Input('interval2', 'n_intervals')])
    
def update_data(n_intervals):

    print("interval ",n_intervals)

    data_gold = requests.request("GET", url_gold, headers=headers_gold)
    data_gold = data_gold.text
    data_gold = json.loads(data_gold)
    print(data_gold)
    
    data_currency = requests.request("GET", url_currency, headers=headers_currency, params=querystring)
    data_currency = data_currency.text
    data_currency = json.loads(data_currency)
    
    goldPrice = data_gold['gold']['price']
    timeStamp = data_currency['timestamp']
    my_datetime = datetime.datetime.fromtimestamp(timeStamp) 

    return dict(x=[[my_datetime]], y=[[goldPrice]])
    
if __name__ == '__main__':
    app.run_server()